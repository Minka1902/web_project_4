web project 4
Michael Scharff

i used JS CSS and HTML to build this project

the project is a page of social media. you can see a picture of some very beutiful views and you can like them(not functional yet). you can edit the profile name and about me and can add a post(also not functional). i used the grid technique and flex with everything else.

https://github.com/Minka1902/web_project_4.git
https://minka1902.github.io/web_project_4/