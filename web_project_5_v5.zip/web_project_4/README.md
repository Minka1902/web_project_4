web project 4
Michael Scharff

i used JS CSS and HTML to build this project

the project is a page of social media. you can see a picture of some very beutiful views and you can like them. you can edit the profile name and about me and can add a post. i used the grid technique with the cards and flex with everything else.

BTW thank you for the super useful review you helped me a lot and i really appreciate it.

https://github.com/Minka1902/web_project_4.git
https://minka1902.github.io/web_project_4/